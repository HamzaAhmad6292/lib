from lib import Script

class Script:
    @staticmethod
    def get_ga_text():
        return "GA"

    @staticmethod
    def get_kmeans_text():
        return "KMEANS"
